/**
 * 
 */
package mx.com.gnp.service.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import mx.com.gnp.service.entity.Person;

/**
 * @author jsetien
 *
 */
public interface PersonRepository extends CrudRepository<Person, Long> {

	/**
	 * Obtiene a la persona con base en su ID.
	 * 
	 * @param id
	 *            El id de la persona
	 * @return Un objeto optional que puede contener una persona
	 */
	@Override
	Optional<Person> findById(Long id);

}
