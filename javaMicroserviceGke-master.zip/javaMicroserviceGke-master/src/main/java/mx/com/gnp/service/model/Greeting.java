package mx.com.gnp.service.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Objeto de saludo.
 * 
 * @author jsetien
 *
 */
@Getter
@NoArgsConstructor(force = true)
@AllArgsConstructor
public class Greeting {

	/** El identificador. */
	private final long id;

	/** El contenido. */
	private final String content;

}
