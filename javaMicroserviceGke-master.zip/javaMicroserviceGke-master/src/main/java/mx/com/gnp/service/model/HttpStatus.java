/**
 * 
 */
package mx.com.gnp.service.model;

/**
 * @author jsetien
 *
 */
public final class HttpStatus {

    /** Petición aceptada y procesada de manera asíncrona. */
    public static final int ACCEPTED = 202;

    /** Recurso no encontrado. */
    public static final int NOT_FOUND = 404;

    /** OK. */
    public static final int OK = 200;

    /** Solicitud inválida o mal formada. */
    public static final int BAD_REQUEST = 400;

    /**
     * Constructor privado para evitar instancias de clase de constantes.
     */
    private HttpStatus() {
    }

}
