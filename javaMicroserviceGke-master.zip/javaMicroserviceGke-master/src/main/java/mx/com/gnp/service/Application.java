/**
 * 
 */
package mx.com.gnp.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

/**
 * @author jsetien
 *
 */
@Slf4j
@SpringBootApplication
public class Application {
		
	/**
	 * @param args Esta aplicación no requiere de parámetros al inicializar.
	 */
	public static void main(final String[] args) {
		SpringApplication.run(Application.class, args);
		log.info("Java microservice inicializado correctamente");
	}
	
	@Override
    public final String toString() {
        return "Java Microservice Application";
	}

}
