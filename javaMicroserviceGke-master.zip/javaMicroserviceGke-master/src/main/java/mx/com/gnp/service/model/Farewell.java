package mx.com.gnp.service.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Objeto de despedida.
 * 
 * @author jsetien
 *
 */
@Getter
@NoArgsConstructor(force = true)
@AllArgsConstructor
public class Farewell {

	/** El identificador. */
	private final long id;

	/** El contenido. */
	private final String content;

}
