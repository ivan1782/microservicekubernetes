package mx.com.gnp.service.rest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import mockit.Expectations;
import mockit.Mocked;
import mx.com.gnp.service.model.Greeting;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class GreetingMockTest {

	private static final long GREETING_ID = 20L;

	private static final String GREETING = "Hello Pedro";

	private static final String URL_PATH_GREETING = "/template/greeting/";

	/**
	 * RestTempleate de tipo test
	 */
	@Mocked
	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public final void sendGreetingRestMocked() {

		new Expectations() {
			{
				restTemplate.exchange(anyString, (HttpMethod) any, (HttpEntity<?>) any, Greeting.class);
				Greeting body = new Greeting(GREETING_ID, GREETING);
				result = new ResponseEntity<Greeting>(body, HttpStatus.ACCEPTED);
			}
		};

		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

		ResponseEntity<Greeting> response = this.restTemplate.exchange(URL_PATH_GREETING, HttpMethod.GET,
				new HttpEntity<>(headers), Greeting.class);

		Greeting responseGreeting = response.getBody();
		Assert.assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		Assert.assertEquals(GREETING_ID, responseGreeting.getId());
		Assert.assertEquals(GREETING, responseGreeting.getContent());

	}
	
}
