package mx.com.gnp.service.rest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import mx.com.gnp.service.model.Farewell;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class FarewellRestTest {

	private static final String URL_PATH_FAREWELL = "/template/farewell/";

	/**
	 * Puerto local.
	 */
	@LocalServerPort
	private int localPort;

	/**
	 * RestTempleate de tipo test
	 */
	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public final void sendGreetingRest() {

		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

		ResponseEntity<Farewell> response = this.restTemplate.exchange(URL_PATH_FAREWELL, HttpMethod.GET,
				new HttpEntity<>(headers), Farewell.class);

		Assert.assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		Assert.assertTrue(response.hasBody());

	}

}
