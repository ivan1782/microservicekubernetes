insert into PERSON values (1, 'Pedro', 'López', 20);
